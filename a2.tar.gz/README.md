# csc443-a2

[Assignment 2](http://www.cdf.toronto.edu/~csc443h/fall/posted_assignments/a2/a2.html)

### Setup

Using Python 3.5.1:

```shell
pyvenv venv                      # create virtualenv
source venv/bin/activate.fish    # activate virtualenv
pip install -r requirements.txt  # install dependencies
jupyter notebook                 # start jupyter
```
